from __future__ import annotations

import sys
import time
import subprocess
import os
from pathlib import Path

# --- PyQt6 Imports ---
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QPainter, QPixmap, QIcon
from PyQt6.QtWidgets import (
    QApplication, QWidget, QSplashScreen, QMainWindow, QVBoxLayout, QHBoxLayout,
    QPushButton, QFileDialog, QLabel, QLineEdit, QTextEdit, QProgressBar,
    QMessageBox, QComboBox
)

# --- Global Definitions ---
APP_NAME = "DMG of Death"
ORG_NAME = "Death's Head Software"
SPLASH_DURATION = 5.4

# =============================================================================
# Resource Path Helper
# =============================================================================

def resource_path(filename: str) -> Path:
    """
    Returns the correct path to a bundled resource whether running as a
    PyInstaller bundle (sys._MEIPASS) or as a plain script.
    Also checks the current working directory as a fallback.
    """
    # PyInstaller extracts to a temp folder referenced by sys._MEIPASS
    if hasattr(sys, '_MEIPASS'):
        p = Path(sys._MEIPASS) / filename
        if p.exists():
            return p
    # Running as a script - check next to the .py file
    p = Path(__file__).parent / filename
    if p.exists():
        return p
    # Last resort - current working directory
    return Path(filename)

def normalize_app_bundle(path: str) -> str:
    """Return the root of a macOS .app bundle, even if a nested folder was selected."""
    candidate = Path(path).expanduser().resolve()
    for parent in (candidate, *candidate.parents):
        if parent.name.endswith(".app") and (parent / "Contents" / "Info.plist").is_file():
            return str(parent)
    return str(candidate)


# =============================================================================
# Splash Function
# =============================================================================

def create_splash():
    """
    Creates the QSplashScreen matching the suite standard (as seen in Editor of Death etc).
    Loads splash.png scaled to 600x600 (KeepAspectRatio on a square image = no bars),
    paints title at top and org name at bottom, returns a 600x600 splash.
    Falls back to ASCII skull on a dark canvas if splash.png not found.
    """
    try:
        splash_path = resource_path("splash.png")

        if splash_path.exists():
            img = QPixmap(str(splash_path))
            if not img.isNull():
                # Scale square image to 600x600 - no bars, fills the window
                pixmap = img.scaled(600, 600, Qt.AspectRatioMode.KeepAspectRatio,
                                    Qt.TransformationMode.SmoothTransformation)
            else:
                pixmap = QPixmap(600, 600)
                pixmap.fill(QColor(20, 20, 20))
        else:
            # Fallback: dark canvas with ASCII skull
            pixmap = QPixmap(600, 600)
            pixmap.fill(QColor(20, 20, 20))
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 14))
            skull_art = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            for i, line in enumerate(skull_art):
                painter.drawText(150, 220 + (i * 30), line)
            painter.end()

        painter = QPainter(pixmap)

        # Title
        painter.setPen(QColor(255, 255, 255))
        painter.setFont(QFont("Courier", 36, QFont.Weight.Bold))
        r = pixmap.rect(); r.setTop(15); r.setBottom(75)
        painter.drawText(r, Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)

        # Org name
        painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
        fr = pixmap.rect(); fr.setTop(pixmap.height() - 70); fr.setBottom(pixmap.height() - 20)
        painter.drawText(fr, Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)

        painter.end()
        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:", e)
        return None

# =============================================================================
# DMG Creation Worker Thread
# =============================================================================

class DMGCreationWorker(QThread):
    """Worker thread for creating DMG files without blocking the UI."""
    progress = pyqtSignal(str)
    finished = pyqtSignal(bool, str)

    def __init__(self, source_path: str, output_path: str, dmg_name: str,
                 compression: str, input_mode: str):
        super().__init__()
        self.source_path = source_path
        self.output_path = output_path
        self.dmg_name = dmg_name
        self.compression = compression
        self.input_mode = input_mode          # "app" or "folder"

    # ------------------------------------------------------------------
    # PyInstaller onedir .app fix
    # ------------------------------------------------------------------
    # PyInstaller onedir .app bundles carry Mach-O binaries with broken
    # or partial code signatures.  On a read-only DMG, macOS cannot
    # repair them and Finder shows the 🚫 symbol.
    #
    # Modifying the existing .app (removing _CodeSignature, renaming
    # the executable, etc.) is NOT enough — PyInstaller embeds signing
    # data inside the Mach-O binaries themselves.
    #
    # The proven fix (from Packages of Death): build a COMPLETELY NEW
    # .app bundle from scratch on the DMG volume.  Copy only the raw
    # _internal/ payload and Resources/.  Write a fresh Info.plist and
    # a bash-script launcher as CFBundleExecutable.  No Mach-O ever
    # becomes the CFBundleExecutable, so Finder has nothing to reject.

    @staticmethod
    def _is_pyinstaller_onedir_folder(path: str) -> bool:
        """Detect a raw PyInstaller onedir OUTPUT FOLDER.
        These have _internal/ and an executable at the top level,
        NOT wrapped in a .app yet."""
        if not os.path.isdir(path):
            return False
        # Raw onedir: has _internal/ subdir at top level
        internal = os.path.join(path, '_internal')
        return os.path.isdir(internal)

    def _build_fresh_app_from_folder(self, source_folder: str, dest_app: str):
        """Build a clean .app from a raw PyInstaller onedir folder.
        source_folder is e.g. dist/MyApp/ — the folder PyInstaller made.
        dest_app is e.g. /Volumes/MyApp/MyApp.app on the DMG."""
        import plistlib

        folder_name = Path(source_folder).resolve().name  # e.g. "MyApp"

        # --- Find the main executable (same name as folder, or first exe) ---
        exe_name = folder_name
        exe_path = os.path.join(source_folder, exe_name)
        if not os.path.isfile(exe_path):
            for f in sorted(os.listdir(source_folder)):
                candidate = os.path.join(source_folder, f)
                if (os.path.isfile(candidate)
                        and os.access(candidate, os.X_OK)
                        and not f.startswith('.')
                        and f != '_internal'):
                    exe_name = f
                    break

        # --- Create .app structure ---
        macos_dir = os.path.join(dest_app, 'Contents', 'MacOS')
        resources_dir = os.path.join(dest_app, 'Contents', 'Resources')
        os.makedirs(macos_dir, exist_ok=True)
        os.makedirs(resources_dir, exist_ok=True)

        # Copy the entire onedir folder into Contents/MacOS/_internal/
        self.progress.emit("Copying application payload…")
        dest_internal = os.path.join(macos_dir, '_internal')
        cp = subprocess.run(
            ['ditto', source_folder, dest_internal],
            capture_output=True, text=True
        )
        if cp.returncode != 0:
            self.progress.emit(f"Warning: ditto failed: {cp.stderr.strip()}")
            return False

        # Look for .icns icon — check multiple locations PyInstaller uses
        import shutil
        icon_key = ''
        icon_search_dirs = [
            source_folder,                                    # dist/MyApp/
            dest_internal,                                    # …/MacOS/_internal/
            os.path.join(source_folder, '_internal'),        # dist/MyApp/_internal/ (pre-copy)
        ]
        for search_dir in icon_search_dirs:
            if not os.path.isdir(search_dir):
                continue
            for f in os.listdir(search_dir):
                if f.endswith('.icns'):
                    shutil.copy2(
                        os.path.join(search_dir, f),
                        os.path.join(resources_dir, 'icon.icns')
                    )
                    icon_key = 'icon'
                    self.progress.emit(f"Found icon: {f} in {search_dir}")
                    break
            if icon_key:
                break

        # --- Bash launcher as CFBundleExecutable ---
        # cd into _internal first so PyInstaller finds sys._MEIPASS correctly
        launcher_path = os.path.join(macos_dir, folder_name)
        with open(launcher_path, 'w') as f:
            f.write('#!/bin/bash\n')
            f.write('DIR="$(cd "$(dirname "$0")" && pwd)"\n')
            f.write('cd "$DIR/_internal"\n')
            f.write(f'"$DIR/_internal/{exe_name}" "$@"\n')
        os.chmod(launcher_path, 0o755)

        # --- Fresh Info.plist (XML, same as Packages of Death) ---
        bundle_id = f'com.deathshead.{folder_name.lower().replace(" ", "-")}'
        icon_xml = f'\n    <key>CFBundleIconFile</key>\n    <string>{icon_key}</string>' if icon_key else ''
        plist_path = os.path.join(dest_app, 'Contents', 'Info.plist')
        with open(plist_path, 'w') as f:
            f.write(f'''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key>
    <string>{folder_name}</string>
    <key>CFBundleDisplayName</key>
    <string>{folder_name}</string>
    <key>CFBundleIdentifier</key>
    <string>{bundle_id}</string>
    <key>CFBundleVersion</key>
    <string>1.0</string>
    <key>CFBundleExecutable</key>
    <string>{folder_name}</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleSignature</key>
    <string>????</string>
    <key>LSMinimumSystemVersion</key>
    <string>10.13.0</string>
    <key>NSHighResolutionCapable</key>
    <true/>{icon_xml}
</dict>
</plist>
''')

        # --- PkgInfo ---
        with open(os.path.join(dest_app, 'Contents', 'PkgInfo'), 'w') as f:
            f.write('APPL????')

        # --- Ad-hoc sign every Mach-O inside _internal/ ---
        self.progress.emit("Ad-hoc signing binaries in _internal/…")
        signed, skipped = self._adhoc_sign_dir(dest_internal)
        self.progress.emit(f"DEBUG signed {signed} binaries, skipped {skipped}")

        # Verify codesign on the main exe
        main_exe = os.path.join(dest_internal, exe_name)
        if os.path.isfile(main_exe):
            r = subprocess.run(
                ['codesign', '--verify', '--verbose', main_exe],
                capture_output=True, text=True
            )
            self.progress.emit(f"DEBUG codesign verify main exe rc={r.returncode} {r.stderr.strip()[:120]}")

        self.progress.emit("Built fresh .app bundle ✓")
        return True

    def _adhoc_sign_dir(self, directory: str):
        """Walk directory and ad-hoc sign every Mach-O binary found.
        Returns (signed_count, skipped_count)."""
        signed = 0
        skipped = 0
        for root, dirs, files in os.walk(directory):
            dirs[:] = [d for d in dirs if not d.endswith('.dSYM')]
            for fname in files:
                fpath = os.path.join(root, fname)
                if os.path.islink(fpath):
                    skipped += 1
                    continue
                try:
                    with open(fpath, 'rb') as f:
                        magic = f.read(4)
                    if magic in (
                        b'\xfe\xed\xfa\xce',  # MH_MAGIC
                        b'\xce\xfa\xed\xfe',  # MH_CIGAM
                        b'\xfe\xed\xfa\xcf',  # MH_MAGIC_64
                        b'\xcf\xfa\xed\xfe',  # MH_CIGAM_64
                        b'\xca\xfe\xba\xbe',  # FAT_MAGIC
                        b'\xbe\xba\xfe\xca',  # FAT_CIGAM
                    ):
                        r = subprocess.run(
                            ['codesign', '--force', '--sign', '-', fpath],
                            capture_output=True, text=True
                        )
                        if r.returncode == 0:
                            signed += 1
                        else:
                            self.progress.emit(f"DEBUG sign FAIL {fname}: {r.stderr.strip()[:80]}")
                            skipped += 1
                    else:
                        skipped += 1
                except (OSError, IOError):
                    skipped += 1
        return signed, skipped

    # ------------------------------------------------------------------
    def run(self):
        try:
            import shutil
            import tempfile

            # --- Validate source path ---
            if self.input_mode == "app":
                self.source_path = normalize_app_bundle(self.source_path)
                if not os.path.isdir(self.source_path):
                    self.finished.emit(False, f"Error: Application path does not exist: {self.source_path}")
                    return
                if not self.source_path.endswith(".app") or not os.path.isfile(
                    os.path.join(self.source_path, "Contents", "Info.plist")
                ):
                    self.finished.emit(
                        False,
                        "Please select the complete macOS application (.app), "
                        "not its Contents folder or executable.\n\n"
                        f"Selected path: {self.source_path}"
                    )
                    return
            else:
                # Folder mode — just needs to exist
                if not os.path.isdir(self.source_path):
                    self.finished.emit(False, f"Error: Folder does not exist: {self.source_path}")
                    return

            if not os.path.isdir(self.output_path):
                self.finished.emit(False, f"Error: Output directory does not exist: {self.output_path}")
                return

            # Ensure DMG name ends with .dmg
            if not self.dmg_name.endswith('.dmg'):
                self.dmg_name += '.dmg'

            dmg_full_path = os.path.join(self.output_path, self.dmg_name)

            if os.path.exists(dmg_full_path):
                self.finished.emit(False, f"Error: DMG file already exists: {dmg_full_path}")
                return

            # --- Pre-flight disk-space check ---
            self.progress.emit("Checking available disk space…")
            try:
                source_bytes = sum(
                    f.stat().st_size for f in Path(self.source_path).rglob('*') if f.is_file()
                )
                needed = source_bytes * 2
                free_output = shutil.disk_usage(self.output_path).free
                free_tmp = shutil.disk_usage(tempfile.gettempdir()).free
                if free_output < needed:
                    self.finished.emit(
                        False,
                        f"Not enough space on the output volume.\n"
                        f"Estimated need: {needed // (1024 * 1024)} MiB — "
                        f"available: {free_output // (1024 * 1024)} MiB"
                    )
                    return
                if free_tmp < needed:
                    self.finished.emit(
                        False,
                        f"Not enough space in the temp directory ({tempfile.gettempdir()}).\n"
                        f"Estimated need: {needed // (1024 * 1024)} MiB — "
                        f"available: {free_tmp // (1024 * 1024)} MiB\n\n"
                        "Free up space or set TMPDIR to a volume with more room."
                    )
                    return
            except OSError:
                pass  # Best-effort

            dmg_format = 'UDBZ' if self.compression == 'Maximum' else 'UDZO'
            vol_name = os.path.splitext(self.dmg_name)[0]

            # --- Create a sparse HFS+ image (grows on demand) ---
            self.progress.emit("Creating temporary disk image…")
            tmp_sparse = tempfile.mktemp(suffix='.sparseimage', prefix='dmg_rw_')
            mount_point = tempfile.mkdtemp(prefix='dmg_mnt_')

            try:
                r = subprocess.run(
                    ['hdiutil', 'create',
                     '-size', '8g',
                     '-type', 'SPARSE',
                     '-fs', 'HFS+',
                     '-volname', vol_name,
                     tmp_sparse],
                    capture_output=True, text=True
                )
                if r.returncode != 0:
                    self.finished.emit(False, f"Error creating temp image: {r.stderr.strip()}")
                    return

                # hdiutil may append .sparseimage to the path
                if not os.path.exists(tmp_sparse) and os.path.exists(tmp_sparse + '.sparseimage'):
                    tmp_sparse = tmp_sparse + '.sparseimage'

                # --- Mount the sparse image ---
                r = subprocess.run(
                    ['hdiutil', 'attach', tmp_sparse,
                     '-mountpoint', mount_point,
                     '-nobrowse', '-noverify'],
                    capture_output=True, text=True
                )
                if r.returncode != 0:
                    self.finished.emit(False, f"Error mounting temp image: {r.stderr.strip()}")
                    return

                try:
                    # --- Copy from source into mounted HFS+ volume ---
                    self.progress.emit("Copying to disk image…")

                    if self.input_mode == "app":
                        app_name = os.path.basename(self.source_path)
                        dest_app = os.path.join(mount_point, app_name)
                        # Regular .app — straight ditto copy
                        cp = subprocess.run(
                            ['ditto', self.source_path, dest_app],
                            capture_output=True, text=True
                        )
                        if cp.returncode != 0:
                            self.finished.emit(False, f"Error copying app: {cp.stderr.strip()}")
                            return
                        # /Applications symlink for drag-install UX
                        os.symlink("/Applications",
                                   os.path.join(mount_point, "Applications"))

                    else:
                        # Folder mode
                        # If the user picked a dist/ folder containing a single
                        # onedir subfolder, auto-descend into it.
                        effective_source = self.source_path
                        if not self._is_pyinstaller_onedir_folder(effective_source):
                            subdirs = [
                                os.path.join(effective_source, d)
                                for d in os.listdir(effective_source)
                                if os.path.isdir(os.path.join(effective_source, d))
                                and not d.startswith('.')
                                and not d.endswith('.app')
                            ]
                            onedir_subdirs = [d for d in subdirs if self._is_pyinstaller_onedir_folder(d)]
                            if len(onedir_subdirs) == 1:
                                self.progress.emit(f"Auto-detected onedir at: {onedir_subdirs[0]}")
                                effective_source = onedir_subdirs[0]

                        is_onedir = self._is_pyinstaller_onedir_folder(effective_source)

                        if is_onedir:
                            folder_name = Path(effective_source).resolve().name
                            dest_app = os.path.join(mount_point, folder_name + '.app')
                            self.progress.emit(f"Building fresh .app at: {dest_app}")
                            if not self._build_fresh_app_from_folder(effective_source, dest_app):
                                self.finished.emit(False, "Error building fresh .app bundle on DMG")
                                return
                            # Verify what we built
                            self.progress.emit(f"DEBUG dest_app exists: {os.path.isdir(dest_app)}")
                            macos_built = os.path.join(dest_app, 'Contents', 'MacOS')
                            if os.path.isdir(macos_built):
                                self.progress.emit(f"DEBUG MacOS/ contents: {os.listdir(macos_built)}")
                            plist_built = os.path.join(dest_app, 'Contents', 'Info.plist')
                            self.progress.emit(f"DEBUG Info.plist exists: {os.path.isfile(plist_built)}")
                            # /Applications symlink for drag-install UX
                            os.symlink("/Applications",
                                       os.path.join(mount_point, "Applications"))
                        else:
                            # Plain folder — copy each item directly
                            for item in os.listdir(self.source_path):
                                src = os.path.join(self.source_path, item)
                                dst = os.path.join(mount_point, item)
                                if os.path.islink(src):
                                    os.symlink(os.readlink(src), dst)
                                else:
                                    cp = subprocess.run(
                                        ['ditto', src, dst],
                                        capture_output=True, text=True
                                    )
                                    if cp.returncode != 0:
                                        self.finished.emit(
                                            False,
                                            f"Error copying '{item}': {cp.stderr.strip()}"
                                        )
                                        return

                    self.progress.emit("Finalising disk image…")

                finally:
                    # --- Unmount (must succeed before convert) ---
                    time.sleep(1)
                    for _attempt in range(5):
                        det = subprocess.run(
                            ['hdiutil', 'detach', mount_point, '-force'],
                            capture_output=True, text=True
                        )
                        if det.returncode == 0:
                            break
                        time.sleep(2)

                # --- Convert sparse image to compressed read-only DMG ---
                self.progress.emit("Compressing disk image…")
                result = subprocess.run(
                    ['hdiutil', 'convert', tmp_sparse,
                     '-format', dmg_format,
                     '-o', dmg_full_path],
                    capture_output=True, text=True
                )

            finally:
                # Clean up temp files
                for f in (tmp_sparse, tmp_sparse + '.sparseimage'):
                    try:
                        os.unlink(f)
                    except OSError:
                        pass
                try:
                    os.rmdir(mount_point)
                except OSError:
                    pass

            if result.returncode != 0:
                error_text = result.stderr.strip() or result.stdout.strip() or "Unknown error"
                self.finished.emit(
                    False,
                    f"Error creating DMG: {error_text}\n\n"
                    f"Source: {self.source_path}\n"
                    f"Output location: {self.output_path}"
                )
                return

            self.finished.emit(True, f"Successfully created DMG: {dmg_full_path}")

        except Exception as e:
            self.finished.emit(False, f"Unexpected error: {str(e)}")

# =============================================================================
# Main Application Window
# =============================================================================

class DMGOfDeathApp(QMainWindow):
    """Main application window for DMG creation."""
    
    def __init__(self):
        super().__init__()
        self.worker = None
        self.init_ui()
        self.apply_dark_theme()
    
    def init_ui(self):
        """Initialize the user interface."""
        self.setWindowTitle(APP_NAME)
        self.setGeometry(100, 100, 700, 600)
        
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        main_layout = QVBoxLayout()
        central_widget.setLayout(main_layout)
        
        # Title
        title_label = QLabel(APP_NAME)
        title_font = QFont("Courier", 24, QFont.Weight.Bold)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(title_label)
        
        # Subtitle
        subtitle_label = QLabel("Convert macOS Applications & Folders to DMG Files")
        subtitle_font = QFont("Courier", 12)
        subtitle_label.setFont(subtitle_font)
        subtitle_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(subtitle_label)

        main_layout.addSpacing(20)

        # Input Mode Section
        input_mode_label = QLabel("Input Mode:")
        input_mode_label.setFont(QFont("Courier", 11, QFont.Weight.Bold))
        main_layout.addWidget(input_mode_label)

        self.input_mode_combo = QComboBox()
        self.input_mode_combo.addItems(["App Bundle (.app)", "Folder"])
        self.input_mode_combo.currentIndexChanged.connect(self._on_input_mode_changed)
        main_layout.addWidget(self.input_mode_combo)

        main_layout.addSpacing(15)

        # Application / Source Path Section
        self.app_path_label = QLabel("Application Path:")
        self.app_path_label.setFont(QFont("Courier", 11, QFont.Weight.Bold))
        main_layout.addWidget(self.app_path_label)
        
        app_path_layout = QHBoxLayout()
        self.app_path_input = QLineEdit()
        self.app_path_input.setPlaceholderText("Select an .app file...")
        app_path_layout.addWidget(self.app_path_input)
        
        browse_app_btn = QPushButton("Browse")
        browse_app_btn.clicked.connect(self.browse_app)
        app_path_layout.addWidget(browse_app_btn)
        
        main_layout.addLayout(app_path_layout)
        
        main_layout.addSpacing(15)
        
        # Output Path Section
        output_path_label = QLabel("Output Directory:")
        output_path_label.setFont(QFont("Courier", 11, QFont.Weight.Bold))
        main_layout.addWidget(output_path_label)
        
        output_path_layout = QHBoxLayout()
        self.output_path_input = QLineEdit()
        self.output_path_input.setPlaceholderText("Select output directory...")
        self.output_path_input.setText(str(Path.home() / "Desktop"))
        output_path_layout.addWidget(self.output_path_input)
        
        browse_output_btn = QPushButton("Browse")
        browse_output_btn.clicked.connect(self.browse_output)
        output_path_layout.addWidget(browse_output_btn)
        
        main_layout.addLayout(output_path_layout)
        
        main_layout.addSpacing(15)
        
        # DMG Name Section
        dmg_name_label = QLabel("DMG Filename:")
        dmg_name_label.setFont(QFont("Courier", 11, QFont.Weight.Bold))
        main_layout.addWidget(dmg_name_label)
        
        self.dmg_name_input = QLineEdit()
        self.dmg_name_input.setPlaceholderText("Enter DMG filename (without .dmg extension)...")
        main_layout.addWidget(self.dmg_name_input)
        
        main_layout.addSpacing(15)
        
        # Compression Section
        compression_label = QLabel("Compression Level:")
        compression_label.setFont(QFont("Courier", 11, QFont.Weight.Bold))
        main_layout.addWidget(compression_label)
        
        self.compression_combo = QComboBox()
        self.compression_combo.addItems(["Standard", "Maximum"])
        main_layout.addWidget(self.compression_combo)
        
        main_layout.addSpacing(20)
        
        # Progress Bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        main_layout.addWidget(self.progress_bar)
        
        # Status/Log Area
        status_label = QLabel("Status:")
        status_label.setFont(QFont("Courier", 11, QFont.Weight.Bold))
        main_layout.addWidget(status_label)
        
        self.status_text = QTextEdit()
        self.status_text.setReadOnly(True)
        self.status_text.setMaximumHeight(150)
        main_layout.addWidget(self.status_text)
        
        main_layout.addSpacing(15)
        
        # Buttons
        button_layout = QHBoxLayout()
        
        create_btn = QPushButton("Create DMG")
        create_btn.setFont(QFont("Courier", 11, QFont.Weight.Bold))
        create_btn.clicked.connect(self.create_dmg)
        button_layout.addWidget(create_btn)
        
        clear_btn = QPushButton("Clear")
        clear_btn.setFont(QFont("Courier", 11, QFont.Weight.Bold))
        clear_btn.clicked.connect(self.clear_fields)
        button_layout.addWidget(clear_btn)
        
        main_layout.addLayout(button_layout)
        
        main_layout.addStretch()
    
    def apply_dark_theme(self):
        """Apply a dark theme to the application."""
        dark_stylesheet = """
            QMainWindow {
                background-color: #1e1e1e;
            }
            QWidget {
                background-color: #1e1e1e;
                color: #ffffff;
            }
            QLabel {
                color: #ffffff;
            }
            QLineEdit {
                background-color: #2d2d2d;
                color: #ffffff;
                border: 1px solid #444444;
                border-radius: 4px;
                padding: 5px;
            }
            QLineEdit:focus {
                border: 1px solid #666666;
            }
            QTextEdit {
                background-color: #2d2d2d;
                color: #ffffff;
                border: 1px solid #444444;
                border-radius: 4px;
            }
            QPushButton {
                background-color: #404040;
                color: #ffffff;
                border: 1px solid #555555;
                border-radius: 4px;
                padding: 8px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #505050;
            }
            QPushButton:pressed {
                background-color: #303030;
            }
            QComboBox {
                background-color: #2d2d2d;
                color: #ffffff;
                border: 1px solid #444444;
                border-radius: 4px;
                padding: 5px;
            }
            QComboBox::drop-down {
                border: none;
            }
            QComboBox::down-arrow {
                image: none;
            }
            QComboBox QAbstractItemView {
                background-color: #2d2d2d;
                color: #ffffff;
                selection-background-color: #404040;
            }
            QProgressBar {
                background-color: #2d2d2d;
                border: 1px solid #444444;
                border-radius: 4px;
                text-align: center;
                color: #ffffff;
            }
            QProgressBar::chunk {
                background-color: #4a7c59;
            }
        """
        self.setStyleSheet(dark_stylesheet)
    
    def _on_input_mode_changed(self, index: int):
        """Update labels and placeholders when the input mode changes."""
        if index == 0:
            self.app_path_label.setText("Application Path:")
            self.app_path_input.setPlaceholderText("Select an .app file...")
        else:
            self.app_path_label.setText("Folder Path:")
            self.app_path_input.setPlaceholderText("Select a folder...")
        self.app_path_input.clear()
        self.dmg_name_input.clear()

    def _is_folder_mode(self) -> bool:
        return self.input_mode_combo.currentIndex() == 1

    def browse_app(self):
        """Open file/folder dialog to select the source."""
        if self._is_folder_mode():
            dir_path = QFileDialog.getExistingDirectory(
                self, "Select Folder", str(Path.home())
            )
            if dir_path:
                self.app_path_input.setText(dir_path)
                self.dmg_name_input.setText(os.path.basename(dir_path))
            return

        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Application",
            str(Path.home() / "Applications"),
            "macOS Applications (*.app);;All Files (*)"
        )
        if file_path:
            app_path = normalize_app_bundle(file_path)
            if not app_path.endswith(".app") or not os.path.isfile(
                os.path.join(app_path, "Contents", "Info.plist")
            ):
                QMessageBox.warning(
                    self,
                    "Select an Application Bundle",
                    "Please select the complete .app application, not its Contents folder or executable."
                )
                return
            self.app_path_input.setText(app_path)
            app_name = os.path.splitext(os.path.basename(app_path))[0]
            self.dmg_name_input.setText(app_name)
    
    def browse_output(self):
        """Open directory dialog to select output location."""
        dir_path = QFileDialog.getExistingDirectory(
            self,
            "Select Output Directory",
            str(Path.home() / "Desktop")
        )
        if dir_path:
            self.output_path_input.setText(dir_path)
    
    def create_dmg(self):
        """Start the DMG creation process."""
        app_path = self.app_path_input.text().strip()
        output_path = self.output_path_input.text().strip()
        dmg_name = self.dmg_name_input.text().strip()
        compression = self.compression_combo.currentText()
        
        # Validation
        if not app_path:
            QMessageBox.warning(self, "Input Error", "Please select an application.")
            return
        
        if not output_path:
            QMessageBox.warning(self, "Input Error", "Please select an output directory.")
            return
        
        if not dmg_name:
            QMessageBox.warning(self, "Input Error", "Please enter a DMG filename.")
            return
        
        # Disable button and show progress
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.status_text.clear()
        self.status_text.append("Starting DMG creation...")
        
        # Create worker thread
        input_mode = "folder" if self._is_folder_mode() else "app"
        self.worker = DMGCreationWorker(app_path, output_path, dmg_name, compression, input_mode)
        self.worker.progress.connect(self.update_status)
        self.worker.finished.connect(self.on_dmg_creation_finished)
        self.worker.start()
    
    def update_status(self, message: str):
        """Update the status text area."""
        self.status_text.append(message)
        self.progress_bar.setValue((self.progress_bar.value() + 25) % 100)
    
    def on_dmg_creation_finished(self, success: bool, message: str):
        """Handle DMG creation completion."""
        self.progress_bar.setVisible(False)
        self.status_text.append(message)
        
        if success:
            QMessageBox.information(self, "Success", message)
        else:
            QMessageBox.critical(self, "Error", message)
    
    def clear_fields(self):
        """Clear all input fields."""
        self.app_path_input.clear()
        self.dmg_name_input.clear()
        self.output_path_input.setText(str(Path.home() / "Desktop"))
        self.status_text.clear()
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(False)

# =============================================================================
# Main Entry Point
# =============================================================================

def activate_splash_on_macos(app, splash):
    """Bring the splash to the foreground on macOS, including Apple Silicon."""
    if sys.platform != "darwin":
        return

    # macOS can leave a newly launched Qt app behind other windows. Activate
    # the application via AppKit when available, then raise the splash window.
    try:
        from AppKit import NSApplication
        NSApplication.sharedApplication().activateIgnoringOtherApps_(True)
    except Exception:
        pass

    splash.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)
    splash.show()
    splash.raise_()
    splash.activateWindow()
    app.setActiveWindow(splash)
    app.processEvents()


if __name__ == '__main__':
    app = QApplication(sys.argv)

    # Display the splash before constructing the main window.
    splash = create_splash()

    if splash:
        splash.show()
        activate_splash_on_macos(app, splash)

        messages = ["Initializing...", "Loading components...", "Preparing interface...", "Almost ready..."]
        delay_per_message = SPLASH_DURATION / len(messages)

        for message in messages:
            splash.showMessage(
                "\n\n\n\n\n\n\n" + message,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                QColor(255, 255, 255)
            )
            splash.raise_()
            if sys.platform == "darwin":
                splash.activateWindow()
            app.processEvents()
            time.sleep(delay_per_message)

        main_window = DMGOfDeathApp()
        main_window.show()
        splash.finish(main_window)
    else:
        main_window = DMGOfDeathApp()
        main_window.show()

    sys.exit(app.exec())
